(ns chunk-memo.bitmap)

(defrecord BitMap [bits])

(def empty-bitmap
  (->BitMap 0N))

(defn bitmap
  ([] empty-bitmap)
  ([values]
   (reduce
    (fn [bm v] (update bm :bits bit-set v))
    empty-bitmap
    values)))

(defn add [bm value]
  (when (neg? value)
    (throw (ex-info "bitmap values must be non-negative"
                    {:value value})))
  (update bm :bits bit-set value))

(defn add-range [bm start end]
  (when (> start end)
    (throw (ex-info "start must be <= end"
                    {:start start :end end})))
  (when (neg? start)
    (throw (ex-info "bitmap values must be non-negative"
                    {:start start})))
  (if (= start end)
    bm
    (let [width (- end start)
          mask  (bit-shift-left (dec (bit-shift-left 1N width)) start)]
      (update bm :bits bit-or mask))))

(defn contains-value? [bm value]
  (and (not (neg? value))
       (bit-test (:bits bm) value)))

(defn cardinality [bm]
  (.bitCount ^BigInteger (:bits bm)))

(defn union [a b]
  (->BitMap (bit-or (:bits a) (:bits b))))

(defn intersection [a b]
  (->BitMap (bit-and (:bits a) (:bits b))))

(defn difference [a b]
  (->BitMap (bit-and (:bits a)
                     (bit-not (:bits b)))))

(defn bitmap-values [bm]
  (letfn [(step [bits]
            (lazy-seq
             (when-not (zero? bits)
               (let [low-bit (bit-and bits (- bits))
                     value   (dec (.bitLength ^BigInteger low-bit))]
                 (cons value
                       (step (bit-xor bits low-bit)))))))]
    (step (:bits bm))))

(defn serialize
  ([bm]
   (serialize bm nil))
  ([bm nbytes]
   (let [bits (:bits bm)
         nbytes (or nbytes
                    (max 1
                         (quot (+ (.bitLength ^BigInteger bits) 7) 8)))]
     (byte-array
      (map
       (fn [i]
         (unchecked-byte
          (bit-and 0xff
                   (bit-shift-right bits (* 8 i)))))
       (range nbytes))))))

(defn deserialize [^bytes data]
  (let [bits
        (reduce
         (fn [acc i]
           (bit-or acc
                   (bit-shift-left
                    (bigint (bit-and 0xff (aget data i)))
                    (* 8 i))))
         0N
         (range (alength data)))]
    (->BitMap bits)))
