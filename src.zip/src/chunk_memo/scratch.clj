(ns scratch
  (:require [chunk-memo.bitmap :as bitmap]))

(+ 1 2)

(def bm
  (-> (bitmap/bitmap [1 3 5])
      (bitmap/add 8)
      (bitmap/add-range 10 14)))

(bitmap/contains-value? bm 12)
;; => true

(bitmap/cardinality bm)
;; => 8

(bitmap/bitmap-values bm)
;; => (1 3 5 8 10 11 12 13)
